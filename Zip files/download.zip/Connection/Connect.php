<?php
$hostName = "sql210.infinityfree.com";
$userName = "if0_42409017";
$pass    =  "uDj6Ebv6HowWC";
$db       = "if0_42409017_shriduruga";

$conn     = mysqli_connect($hostName, $userName, $pass, $db);

if ($conn) {
  //echo"Connected successfuly";
}
else{
    echo"Failed";
}

?>