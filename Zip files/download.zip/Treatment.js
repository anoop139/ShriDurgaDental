   let msg = document.getElementById("errorMessage1")
   let treatExisted = document.getElementById("treatExisted")
   let treat;
         
   function Submit() 
  {
     let date2 = document.getElementById("date2")
 let dueDate = document.getElementById("dueDate")
 let dueDateInput = document.getElementById("dueDateInput")
     treat = document.getElementById("treat1").value 
 let  advance = document.getElementById("Advance") 
 let  online = document.getElementById("onlinePayment") 
 let cashReceived = document.getElementById("receivedAmount")
  let advan =  Number(advance.value) 
  let tot =  Number(cashReceived.value)
  let v   ="0";  
    if (treat.trim()==="") {
      
      msg.innerHTML="Enter treatment please"
      // alert("date is "+date)
          return false 
    }

   if (Number(advance.value) < 0 || Number(online.value) < 0){
        
    alert("Enter positive number");
         return false;
    }
    if (tot<0) {
        alert("Enter valid number");
         return false;
    }
         let date = new Date();
         let d = date.getDate()
         let mo = date.getMonth()+1
        let y = date.getFullYear()
        let toDate = ""
        // if (mo<10) {
                  toDate=d.toString()+" - "+mo.toString()+" - "+y
        // }
        // else {
        //           toDate=d.toString()+" - "+mo.toString()+" - "+y
          
        // }
	// date2.value=toDate;
if (dueDate.value) {
    let parts = dueDate.value.split("-");
    dueDateInput.value = parts[2] + " - " + parts[1] + " - " + parts[0]; 
    // alert("Due date in js file"+ dueDateInput.value);
      
  let x =dueDate.value.split("-").reverse().join(" - ")
  let date = x.slice(0, 7)


//  alert("Due month "+parts[1]+" and current month "+mo)
//  return false 

if (Number(parts[0])<y) {
    alert("Sorry you entered wrong due year ")
    return false
    
  }
   if (y==Number(parts[0]) && mo>Number(parts[1])) {
    alert("Sorry you entered wrong due month")
    return false
    
  }
  if (y== Number(parts[0]) && Number(parts[2])<d && mo==Number(parts[1])) {
    alert("Sorry you entered wrong due date ")
    return false
    
  } 

} 
  
if (advan> 0 && tot==0) {
  
  cashReceived.value = advance.value
  // alert("cash is converted "+cashReceived.value)
  // return false
}

if (dueDate.value.length==0) {
  // alert("no due date And advance is "+dueDate.value)///
  dueDate.value="None"
  }

if (advance.value.trim()==="" || online.value.trim()==="" || cashReceived.value.trim()==="") {
 let p = confirm("Are sure you want to leave with default values ")
  if (p==true) {
    return true
  }
  else{
    return false 
  }
    }

    return true
  }
window.oninput = function() {
  msg.innerHTML = "";
  if (treatExisted) {
    treatExisted.innerHTML = "";
  }
};