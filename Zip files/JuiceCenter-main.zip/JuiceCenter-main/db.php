<?php
// Database connection for Udupi Juice Center.
// Update these values if your MySQL config differs.
$DB_HOST = 'localhost';
$DB_USER = 'root';
$DB_PASS = '';
$DB_NAME = 'udupi_juice_center';

function getDbConnection() {
    global $DB_HOST, $DB_USER, $DB_PASS, $DB_NAME;
    $conn = new mysqli($DB_HOST, $DB_USER, $DB_PASS, $DB_NAME);
    if ($conn->connect_error) {
        die('Database connection failed: ' . $conn->connect_error);
    }

    $createTableSql = "CREATE TABLE IF NOT EXISTS juices (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(100) NOT NULL,
        description TEXT NOT NULL,
        price DECIMAL(8,2) NOT NULL DEFAULT 0.00,
        category VARCHAR(50) DEFAULT 'Juice',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci";

    if (!$conn->query($createTableSql)) {
        die('Table creation failed: ' . $conn->error);
    }

    return $conn;
}
