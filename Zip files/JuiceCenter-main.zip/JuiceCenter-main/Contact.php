<?php
// Contact page for Udupi Juice Center
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us - Udupi Juice Center</title>
    <style>
        body { margin: 0; font-family: Arial, sans-serif; background: #f7f4ec; color: #333; }
        .page-header { background: linear-gradient(135deg, #ffca28, #ff7043); color: #fff; padding: 60px 20px; text-align: center; }
        .page-header h1 { margin: 0; font-size: 3rem; }
        .section { padding: 40px 20px; max-width: 900px; margin: 0 auto; }
        .section h2 { color: #ff7043; margin-bottom: 18px; }
        .contact-card { background: #fff; border-radius: 20px; padding: 28px; box-shadow: 0 12px 30px rgba(0,0,0,0.08); }
        .contact-card p { line-height: 1.7; }
        .contact-list { list-style: none; margin: 0; padding: 0; }
        .contact-list li { margin-bottom: 14px; }
        .contact-list strong { display: block; margin-bottom: 6px; }
        .back-link { display: inline-block; margin-top: 20px; padding: 12px 24px; background: #fff; color: #ff7043; text-decoration: none; border-radius: 30px; font-weight: bold; }
    </style>
</head>
<body>
    <header class="page-header">
        <h1>Contact Us</h1>
        <p>We are happy to hear from you. Reach out for orders, questions, or feedback.</p>
    </header>

    <section class="section">
        <div class="contact-card">
            <h2>Get in Touch</h2>
            <p>If you want to order fresh juice, ask about ingredients, or share feedback, contact us using the details below.</p>
            <ul class="contact-list">
                <li><strong>Location:</strong> Main Street, Udupi Juice Center</li>
                <li><strong>Phone:</strong> +91 12345 67890</li>
                <li><strong>Email:</strong> hello@udupijuicecenter.com</li>
                <li><strong>Opening Hours:</strong> Mon - Sun: 8:00 AM - 8:00 PM</li>
            </ul>
            <a class="back-link" href="HomePage.php">Back to Home</a>
        </div>
    </section>
</body>
</html>
