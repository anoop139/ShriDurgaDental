    <?php
    //testinngt
session_start();
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    header('Location: Login.php');
    exit;
}

require_once 'db.php';
$conn = getDbConnection();
$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['delete_all'])) {
        $stmt = $conn->prepare('DELETE FROM juices');
        if ($stmt->execute()) {
            $message = 'All juices have been deleted successfully.';
        } else {
            $message = 'Error deleting all juices: ' . $stmt->error;
        }
        $stmt->close();
    } elseif (isset($_POST['delete_id'])) {
        $deleteId = intval($_POST['delete_id']);
        if ($deleteId > 0) {
            $stmt = $conn->prepare('DELETE FROM juices WHERE id = ?');
            $stmt->bind_param('i', $deleteId);
            if ($stmt->execute()) {
                $message = 'Juice deleted successfully.';
            } else {
                $message = 'Error deleting juice: ' . $stmt->error;
            }
            $stmt->close();
        }
    } else {
        $name = trim($_POST['name'] ?? '');
        $description = trim($_POST['description'] ?? '');
        $price = trim($_POST['price'] ?? '');
        $category = trim($_POST['category'] ?? 'Juice');

        if ($name === '' || $description === '' || $price === '') {
            $message = 'Please fill in all required fields.';
        } elseif (!is_numeric($price) || floatval($price) < 0) {
            $message = 'Price must be a valid positive number.';
        } else {
            $stmt = $conn->prepare('INSERT INTO juices (name, description, price, category) VALUES (?, ?, ?, ?)');
            $priceValue = floatval($price);
            $stmt->bind_param('ssds', $name, $description, $priceValue, $category);

            if ($stmt->execute()) {
                $insertId = $stmt->insert_id;
                $juiceInfoDir = __DIR__ . '/juice_files';
                if (!is_dir($juiceInfoDir)) {
                    mkdir($juiceInfoDir, 0755, true);
                }
                $slug = preg_replace('/[^a-z0-9]+/', '_', strtolower($name));
                $slug = trim($slug, '_');
                $filePath = $juiceInfoDir . '/juice_' . $insertId . '_' . $slug . '.txt';
                $fileContents = "Name: {$name}\n";
                $fileContents .= "Description: {$description}\n";
                $fileContents .= "Category: {$category}\n";
                $fileContents .= "Price: ₹" . number_format($priceValue, 2) . "\n";
                $fileContents .= "Created At: " . date('Y-m-d H:i:s') . "\n";
                file_put_contents($filePath, $fileContents);

                $message = 'New juice added successfully.';
                $name = $description = '';
                $price = '';
                $category = 'Juice';
            } else {
                $message = 'Error adding juice: ' . $stmt->error;
            }

            $stmt->close();
        }
    }
}

$juiceList = [];
$result = $conn->query('SELECT id, name, category, price FROM juices ORDER BY created_at DESC');
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $juiceList[] = $row;
    }
    $result->free();
}

// Load distinct categories (juice types) from the database. Fall back to defaults if none exist.
$categories = [];
$catResult = $conn->query("SELECT DISTINCT category FROM juices ORDER BY category ASC");
if ($catResult) {
    while ($crow = $catResult->fetch_assoc()) {
        $categories[] = $crow['category'];
    }
    $catResult->free();
}
if (empty($categories)) {
    $categories = ['Juice', 'Smoothie', 'Shot'];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add New Juice - Udupi Juice Center</title>
    <style>
        body { margin: 0; font-family: Arial, sans-serif; background: #f7f4ec; color: #333; }
        .page-header { background: linear-gradient(135deg, #ffca28, #ff7043); color: #fff; padding: 50px 20px; text-align: center; }
        .page-header h1 { margin: 0; font-size: 2.8rem; }
        .section { padding: 40px 20px; max-width: 900px; margin: 0 auto; }
        .form-card { background: #fff; border-radius: 20px; padding: 28px; box-shadow: 0 12px 30px rgba(0,0,0,0.08); }
        .form-card label { display: block; margin-bottom: 10px; font-weight: 600; }
        .form-card input,
        .form-card textarea,
        .form-card select { width: 100%; padding: 12px 14px; margin-bottom: 18px; border: 1px solid #e0e0e0; border-radius: 12px; font-size: 1rem; }
        .form-card button { background: #ff7043; color: #fff; border: none; padding: 14px 24px; border-radius: 30px; cursor: pointer; font-size: 1rem; }
        .form-card button:hover { background: #f4511e; }
        .message { margin-bottom: 18px; padding: 16px 20px; border-radius: 16px; background: #fff3e0; color: #bf360c; }
        .juice-table { width: 100%; border-collapse: collapse; margin-top: 30px; }
        .juice-table th,
        .juice-table td { padding: 14px 16px; border-bottom: 1px solid #efebe9; text-align: left; }
        .juice-table th { background: #fff3e0; }
        .delete-btn { background: #ff7043; color: #fff; border: none; padding: 10px 16px; border-radius: 999px; cursor: pointer; font-weight: 700; }
        .delete-btn:hover { background: #e64a19; }
        .delete-all-btn { background: #d32f2f; color: #fff; border: none; padding: 16px 24px; border-radius: 36px; cursor: pointer; font-weight: 700; min-width: 220px; font-size: 1rem; }
        .delete-all-btn:hover { background: #b71c1c; }
        .delete-all-form { position: fixed; right: 24px; bottom: 24px; z-index: 1000; }
        .detail-link { color: #ff7043; font-weight: 700; text-decoration: none; }
        .detail-link:hover { text-decoration: underline; }
        .juice-table th,
        .juice-table td { padding: 14px 16px; border-bottom: 1px solid #efebe9; text-align: left; }
        .juice-table th { background: #fff3e0; }
        .back-link { display: inline-block; margin-top: 16px; color: #ff7043; text-decoration: none; font-weight: bold; }
        .top-nav { background: rgba(255, 250, 245, 0.96); border-bottom: 1px solid rgba(255,112,67,0.18); padding: 14px 24px; display: flex; justify-content: space-between; align-items: center; position: sticky; top: 0; z-index: 1000; }
        .top-nav .brand { font-size: 1rem; font-weight: bold; color: #ff7043; text-transform: uppercase; letter-spacing: 0.08em; }
        .top-nav .nav-link { color: #333; text-decoration: none; font-weight: 700; padding: 8px 12px; border-radius: 999px; }
        .top-nav .nav-link:hover { background: rgba(255,112,67,0.12); color: #ff7043; }
    </style>
</head>
<body>
    <nav class="top-nav">
        <div class="brand">Udupi Juice Center</div>
        <div>
            <a class="nav-link" href="HomePage.php">Home</a>
            <a class="nav-link" href="Logout.php">Logout</a>
        </div>
    </nav>
    <header class="page-header">
        <h1>Add New Juice</h1>
        <p>Use this form to add a new juice to the menu. The juice is saved in the database.</p>
    </header>

    <section class="section">
        <div class="form-card">
            <?php if ($message !== ''): ?>
                <div class="message"><?php echo htmlspecialchars($message, ENT_QUOTES); ?></div>
            <?php endif; ?>

            <form method="post" action="AddJuice.php">
                <label for="name">Juice Name</label>
                <input type="text" id="name" name="name" value="<?php echo htmlspecialchars($name ?? '', ENT_QUOTES); ?>" required>

                <label for="description">Description</label>
                <textarea id="description" name="description" rows="5" required><?php echo htmlspecialchars($description ?? '', ENT_QUOTES); ?></textarea>

                <label for="price">Price (INR)</label>
                <input type="number" step="0.01" id="price" name="price" value="<?php echo htmlspecialchars($price ?? '', ENT_QUOTES); ?>" required>

                <label for="category">Category</label>
                <select id="category" name="category">
                    <?php foreach ($categories as $cat): ?>
                        <option value="<?php echo htmlspecialchars($cat, ENT_QUOTES); ?>"<?php echo (isset($category) && $category === $cat) ? ' selected' : ''; ?>><?php echo htmlspecialchars($cat, ENT_QUOTES); ?></option>
                    <?php endforeach; ?>
                </select>

                <button type="submit">Save Juice</button>
            </form>

            <a class="back-link" href="HomePage.php">Back to Home</a>
        </div>

        <?php if (!empty($juiceList)): ?>
        <form method="post" action="AddJuice.php" onsubmit="return confirm('Delete all juices? This cannot be undone.');" class="delete-all-form">
            <button type="submit" name="delete_all" value="1" class="delete-all-btn">Delete All Juices</button>
        </form>

        <table class="juice-table">
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Category</th>
                    <th>Price</th>
                    <th>Links</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($juiceList as $juice): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($juice['name'], ENT_QUOTES); ?></td>
                        <td><?php echo htmlspecialchars($juice['category'], ENT_QUOTES); ?></td>
                        <td>₹<?php echo htmlspecialchars(number_format($juice['price'], 2), ENT_QUOTES); ?></td>
                        <td>
                            <a class="detail-link" href="JuiceDetail.php?id=<?php echo (int) $juice['id']; ?>">Click here to view detail</a>
                        </td>
                        <td>
                            <form method="post" action="AddJuice.php" onsubmit="return confirm('Delete this juice?');" style="display:inline-block;">
                                <input type="hidden" name="delete_id" value="<?php echo (int) $juice['id']; ?>">
                                <button type="submit" class="delete-btn">Delete</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <?php endif; ?>
    </section>
</body>
</html>
