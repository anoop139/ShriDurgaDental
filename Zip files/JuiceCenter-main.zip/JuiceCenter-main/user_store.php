<?php
function getUserFilePath() {
    return __DIR__ . '/users.json';
}

function loadUsers() {
    $filePath = getUserFilePath();
    if (!file_exists($filePath)) {
        $defaultUsers = [
            [
                'username' => 'admin',
                'password' => password_hash('secret123', PASSWORD_DEFAULT),
            ],
        ];
        file_put_contents($filePath, json_encode($defaultUsers, JSON_PRETTY_PRINT));
        return $defaultUsers;
    }

    $json = file_get_contents($filePath);
    $users = json_decode($json, true);
    return is_array($users) ? $users : [];
}

function saveUsers(array $users) {
    file_put_contents(getUserFilePath(), json_encode($users, JSON_PRETTY_PRINT));
}

function findUser(string $username) {
    $users = loadUsers();
    foreach ($users as $user) {
        if (isset($user['username']) && $user['username'] === $username) {
            return $user;
        }
    }
    return null;
}

function usernameExists(string $username): bool {
    return findUser($username) !== null;
}

function addUser(string $username, string $password): bool {
    if (usernameExists($username)) {
        return false;
    }
    $users = loadUsers();
    $users[] = [
        'username' => $username,
        'password' => password_hash($password, PASSWORD_DEFAULT),
    ];
    saveUsers($users);
    return true;
}
