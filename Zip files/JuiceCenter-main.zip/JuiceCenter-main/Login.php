<?php
session_start();
require_once 'user_store.php';

$message = '';

if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true) {
    header('Location: AddJuice.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = trim($_POST['password'] ?? '');

    $user = findUser($username);
    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['logged_in'] = true;
        $_SESSION['username'] = $username;
        header('Location: AddJuice.php');
        exit;
    }

    $message = 'Invalid username or password. Please try again.';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Login - Udupi Juice Center</title>
    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background: linear-gradient(135deg, #f8f0e3, #fff8f1);
            color: #333;
            display: flex;
            align-items: center;
            justify-content: center;
            min-height: 100vh;
        }
        .login-card {
            width: 100%;
            max-width: 420px;
            background: #ffffff;
            border-radius: 24px;
            box-shadow: 0 20px 50px rgba(0, 0, 0, 0.12);
            padding: 36px 32px;
        }
        .login-card h1 {
            margin: 0 0 14px;
            font-size: 2rem;
            color: #ff7043;
        }
        .login-card p {
            margin: 0 0 24px;
            line-height: 1.6;
            color: #5d4037;
        }
        .login-card label {
            display: block;
            margin-bottom: 8px;
            font-weight: 700;
            color: #5d4037;
        }
        .login-card input {
            width: 100%;
            padding: 14px 16px;
            margin-bottom: 18px;
            border: 1px solid #e0e0e0;
            border-radius: 12px;
            font-size: 1rem;
        }
        .login-card button {
            width: 100%;
            border: none;
            border-radius: 999px;
            padding: 14px 18px;
            background: #ff7043;
            color: #fff;
            font-size: 1rem;
            font-weight: 700;
            cursor: pointer;
        }
        .login-card button:hover {
            background: #e64a19;
        }
        .message {
            margin-bottom: 18px;
            padding: 14px 16px;
            border-radius: 14px;
            background: #ffebee;
            color: #c62828;
            border: 1px solid #ffcdd2;
        }
        .login-footer {
            margin-top: 20px;
            text-align: center;
            color: #7b5e57;
            font-size: 0.95rem;
        }
    </style>
</head>
<body>
    <div class="login-card">
        <h1>Login</h1>
        <p>Enter your username and password to access the juice management area.</p>

        <?php if ($message !== ''): ?>
            <div class="message"><?php echo htmlspecialchars($message, ENT_QUOTES); ?></div>
        <?php endif; ?>

        <form method="post" action="Login.php">
            <label for="username">Username</label>
            <input type="text" id="username" name="username" required value="<?php echo htmlspecialchars($_POST['username'] ?? '', ENT_QUOTES); ?>" />

            <label for="password">Password</label>
            <input type="password" id="password" name="password" required />

            <button type="submit">Sign In</button>
        </form>

        <div class="login-footer">
            Don't have an account? <a href="Signup.php">Sign up here</a><br/>
        </div>
    </div>
</body>
</html>
