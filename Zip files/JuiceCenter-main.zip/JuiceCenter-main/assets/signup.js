document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('signup-form');
    const usernameInput = document.getElementById('username');
    const passwordInput = document.getElementById('password');
    const confirmInput = document.getElementById('confirm_password');
    const signupMessage = document.getElementById('signup-message');

    if (!form || !usernameInput || !passwordInput || !confirmInput) {
        return;
    }

    const showMessage = (text) => {
        if (!signupMessage) {
            return;
        }
        signupMessage.textContent = text;
        signupMessage.style.display = 'block';
    };

    const clearMessage = () => {
        if (!signupMessage) {
            return;
        }
        signupMessage.textContent = '';
        signupMessage.style.display = 'none';
    };

    const passwordHint = document.getElementById('password-hint');
    const confirmHint = document.getElementById('confirm-hint');

    const showPasswordHint = () => {
        if (!passwordHint || !confirmHint) {
            return;
        }

        const password = passwordInput.value;
        const confirmValue = confirmInput.value;
        const length = password.length;
        const minLength = 6;
        const specialCharRegex = /[^a-zA-Z0-9]/;

        if (length === 0) {
            passwordHint.textContent = '';
            passwordHint.style.display = 'none';
        } else if (length < minLength) {
            const remaining = minLength - length;
            passwordHint.textContent = `Password needs ${remaining} more character${remaining === 1 ? '' : 's'}.`;
            passwordHint.style.display = 'block';
            passwordHint.style.background = '#fff3e0';
            passwordHint.style.color = '#bf360c';
            passwordHint.style.borderColor = '#ffe0b2';
        } else if (!specialCharRegex.test(password)) {
            passwordHint.textContent = 'Password must include at least one special character.';
            passwordHint.style.display = 'block';
            passwordHint.style.background = '#fff3e0';
            passwordHint.style.color = '#bf360c';
            passwordHint.style.borderColor = '#ffe0b2';
        } else {
            passwordHint.textContent = 'Strong password!';
            passwordHint.style.display = 'block';
            passwordHint.style.background = '#e8f5e9';
            passwordHint.style.color = '#2e7d32';
            passwordHint.style.borderColor = '#c8e6c9';
        }

        if (confirmValue.length === 0) {
            confirmHint.textContent = '';
            confirmHint.style.display = 'none';
            return;
        }

        if (password === confirmValue) {
            confirmHint.textContent = 'Password match.';
            confirmHint.style.display = 'block';
            confirmHint.style.background = '#e8f5e9';
            confirmHint.style.color = '#2e7d32';
            confirmHint.style.borderColor = '#c8e6c9';
        } else {
            confirmHint.textContent = 'Passwords do not match.';
            confirmHint.style.display = 'block';
            confirmHint.style.background = '#ffebee';
            confirmHint.style.color = '#c62828';
            confirmHint.style.borderColor = '#ffcdd2';
        }
    };

    form.addEventListener('submit', (event) => {
        clearMessage();

        const username = usernameInput.value.trim();
        const password = passwordInput.value;
        const confirmPassword = confirmInput.value;
        const usernameRegex = /^[a-zA-Z0-9_]{3,20}$/;
        const specialCharRegex = /[^a-zA-Z0-9]/;

        if (!usernameRegex.test(username)) {
            event.preventDefault();
            showMessage('Username must be 3-20 characters and may include letters, numbers, or underscores.');
            return;
        }

        if (password.length < 6) {
            event.preventDefault();
            showMessage('Password must be at least 6 characters long.');
            return;
        }

        if (!specialCharRegex.test(password)) {
            event.preventDefault();
            showMessage('Password must include at least one special character.');
            return;
        }

        if (password !== confirmPassword) {
            event.preventDefault();
            showMessage('Passwords do not match.');
            return;
        }
    });

    passwordInput.addEventListener('input', showPasswordHint);
    confirmInput.addEventListener('input', showPasswordHint);

    form.addEventListener('submit', (event) => {
        clearMessage();

        const username = usernameInput.value.trim();
        const password = passwordInput.value;
        const confirmPassword = confirmInput.value;
        const usernameRegex = /^[a-zA-Z0-9_]{3,20}$/;

        if (!usernameRegex.test(username)) {
            event.preventDefault();
            showMessage('Username must be 3-20 characters and may include letters, numbers, or underscores.');
            return;
        }

        if (password.length < 6) {
            event.preventDefault();
            showMessage('Password must be at least 6 characters long.');
            return;
        }

        if (password !== confirmPassword) {
            event.preventDefault();
            showMessage('Passwords do not match.');
            return;
        }
    });
});