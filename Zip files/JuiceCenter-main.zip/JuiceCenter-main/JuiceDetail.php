<?php
require_once 'db.php';
$conn = getDbConnection();

$juice = null;
$message = '';

if (isset($_GET['id'])) {
    $id = intval($_GET['id']);
    if ($id > 0) {
            $stmt = $conn->prepare('SELECT id, name, description, price, category, created_at FROM juices WHERE id = ?');
        $stmt->bind_param('i', $id);
        if ($stmt->execute()) {
            $result = $stmt->get_result();
            $juice = $result->fetch_assoc();
            $result->free();
        } else {
            $message = 'Error loading juice details: ' . $stmt->error;
        }
        $stmt->close();
    }
} else {
    $message = 'No juice selected.';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Juice Details - Udupi Juice Center</title>
    <style>
        body { margin: 0; font-family: Arial, sans-serif; background: #f7f4ec; color: #333; }
        .page-header { background: linear-gradient(135deg, #ffca28, #ff7043); color: #fff; padding: 50px 20px; text-align: center; }
        .page-header h1 { margin: 0; font-size: 2.8rem; }
        .section { padding: 40px 20px; max-width: 900px; margin: 0 auto; }
        .detail-card { background: #fff; border-radius: 20px; padding: 28px; box-shadow: 0 12px 30px rgba(0,0,0,0.08); }
        .detail-card h2 { margin-top: 0; color: #ff7043; }
        .detail-card p { line-height: 1.7; margin: 16px 0; }
        .detail-card .meta { display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 16px; margin-top: 24px; }
        .detail-card .meta div { background: #fff8f1; border-radius: 14px; padding: 18px; }
        .detail-card .meta label { display: block; font-weight: 700; margin-bottom: 8px; color: #5d4037; }
        .back-link { display: inline-flex; align-items: center; margin-top: 24px; color: #ff7043; text-decoration: none; font-weight: bold; }
        .message { background: #fff3e0; color: #bf360c; padding: 16px 18px; border-radius: 14px; margin-bottom: 20px; }
    </style>
</head>
<body>
    <header class="page-header">
        <h1>Juice Details</h1>
        <p>Learn more about your selected juice.</p>
    </header>

    <section class="section">
        <div class="detail-card">
            <?php if ($message !== ''): ?>
                <div class="message"><?php echo htmlspecialchars($message, ENT_QUOTES); ?></div>
            <?php endif; ?>

            <?php if ($juice): ?>
                <h2><?php echo htmlspecialchars($juice['name'], ENT_QUOTES); ?></h2>
                <p><?php echo nl2br(htmlspecialchars($juice['description'], ENT_QUOTES)); ?></p>
                <div class="meta">
                    <div>
                        <label>Category</label>
                        <p><?php echo htmlspecialchars($juice['category'], ENT_QUOTES); ?></p>
                    </div>
                    <div>
                        <label>Price</label>
                        <p>₹<?php echo htmlspecialchars(number_format($juice['price'], 2), ENT_QUOTES); ?></p>
                    </div>
                    <div>
                        <label>Date &amp; Time</label>
                        <p>
                            <?php $dt = strtotime($juice['created_at']); ?>
                            <?php echo htmlspecialchars(date('Y-m-d', $dt), ENT_QUOTES); ?><br>
                            <?php echo htmlspecialchars(date('h:i A', $dt), ENT_QUOTES); ?>
                        </p>
                    </div>
                </div>
            <?php else: ?>
                <p>No juice details available.</p>
            <?php endif; ?>

            <a href="HomePage.php" class="back-link">&larr; Back to home</a>
        </div>
    </section>
</body>
</html>
