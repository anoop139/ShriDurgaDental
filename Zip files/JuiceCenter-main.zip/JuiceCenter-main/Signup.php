<?php
session_start();
require_once 'user_store.php';

if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true) {
    header('Location: AddJuice.php');
    exit;
}

$message = '';
$username = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = trim($_POST['password'] ?? '');
    $confirm = trim($_POST['confirm_password'] ?? '');

    if ($username === '' || $password === '' || $confirm === '') {
        $message = 'Please fill in all fields.';
    } elseif (!preg_match('/^[a-zA-Z0-9_]{3,20}$/', $username)) {
        $message = 'Username must be 3-20 characters and may include letters, numbers, or underscores.';
    } elseif (strlen($password) < 6) {
        $message = 'Password must be at least 6 characters long.';
    } elseif (!preg_match('/[^a-zA-Z0-9]/', $password)) {
        $message = 'Password must include at least one special character.';
    } elseif ($password !== $confirm) {
        $message = 'Passwords do not match.';
    } elseif (usernameExists($username)) {
        $message = 'Username is already taken. Please choose another one.';
    } else {
        if (addUser($username, $password)) {
            header('Location: Login.php');
            exit;
        }
        $message = 'Unable to create account. Please try again.';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Sign Up - Udupi Juice Center</title>
    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background: linear-gradient(135deg, #f8f0e3, #fff8f1);
            color: #333;
            display: flex;
            align-items: center;
            justify-content: center;
            min-height: 100vh;
        }
        .login-card {
            width: 100%;
            max-width: 420px;
            background: #ffffff;
            border-radius: 24px;
            box-shadow: 0 20px 50px rgba(0, 0, 0, 0.12);
            padding: 36px 32px;
        }
        .login-card h1 {
            margin: 0 0 14px;
            font-size: 2rem;
            color: #ff7043;
        }
        .login-card p {
            margin: 0 0 24px;
            line-height: 1.6;
            color: #5d4037;
        }
        .login-card label {
            display: block;
            margin-bottom: 8px;
            font-weight: 700;
            color: #5d4037;
        }
        .login-card input {
            width: 100%;
            padding: 14px 16px;
            margin-bottom: 18px;
            border: 1px solid #e0e0e0;
            border-radius: 12px;
            font-size: 1rem;
        }
        .login-card button {
            width: 100%;
            border: none;
            border-radius: 999px;
            padding: 14px 18px;
            background: #ff7043;
            color: #fff;
            font-size: 1rem;
            font-weight: 700;
            cursor: pointer;
        }
        .login-card button:hover {
            background: #e64a19;
        }
        .message {
            margin-bottom: 18px;
            padding: 14px 16px;
            border-radius: 14px;
            background: #ffebee;
            color: #c62828;
            border: 1px solid #ffcdd2;
        }
        .login-footer {
            margin-top: 20px;
            text-align: center;
            color: #7b5e57;
            font-size: 0.95rem;
        }
        .login-footer a {
            color: #ff7043;
            text-decoration: none;
            font-weight: 700;
        }
    </style>
</head>
<body>
    <div class="login-card">
        <h1>Sign Up</h1>
        <p>Create a new account to manage juices.</p>

        <?php if ($message !== ''): ?>
            <div id="server-message" class="message"><?php echo htmlspecialchars($message, ENT_QUOTES); ?></div>
        <?php endif; ?>

        <div id="signup-message" class="message" style="display: none;"></div>

        <form id="signup-form" method="post" action="Signup.php">
            <label for="username">Username</label>
            <input type="text" id="username" name="username" required value="<?php echo htmlspecialchars($username, ENT_QUOTES); ?>" />

            <label for="password">Password</label>
            <input type="password" id="password" name="password" required />
            <div id="password-hint" class="message" style="display: none; margin-top: -12px; margin-bottom: 18px; background: #fff3e0; color: #bf360c; border-color: #ffe0b2; padding: 10px 14px;"></div>

            <label for="confirm_password">Confirm Password</label>
            <input type="password" id="confirm_password" name="confirm_password" required />
            <div id="confirm-hint" class="message" style="display: none; margin-top: -12px; margin-bottom: 18px; background: #e8f5e9; color: #2e7d32; border-color: #c8e6c9; padding: 10px 14px;"></div>

            <button type="submit">Create Account</button>
        </form>

        <div class="login-footer">
            Already have an account? <a href="Login.php">Sign in here</a>
        </div>
    </div>
    <script src="assets/signup.js"></script>
</body>
</html>
