﻿<?php
// Home page for Udupi Juice Center
require_once 'db.php';
$conn = getDbConnection();
$juices = [];
$res = $conn->query("SELECT id, name, description, price, category FROM juices ORDER BY created_at DESC");
if ($res) {
    while ($r = $res->fetch_assoc()) {
        $juices[] = $r;
    }
    $res->free();
}
$bestSellers = array_slice($juices, 0, 4);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Udupi Juice Center</title>
    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background: #f7f4ec;
            color: #333;
        }
        .navbar {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            background: rgba(255, 250, 245, 0.96);
            border-bottom: 1px solid rgba(255,112,67,0.18);
            backdrop-filter: blur(10px);
            z-index: 1000;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 14px 24px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.05);
        }
        .navbar .brand {
            font-size: 1.1rem;
            font-weight: bold;
            color: #ff7043;
            text-transform: uppercase;
            letter-spacing: 0.08em;
        }
        .navbar .nav-links {
            list-style: none;
            margin: 0;
            padding: 0;
            display: flex;
            gap: 18px;
        }
        .navbar .nav-links li {
            margin: 0;
            position: relative;
        }
        .navbar .nav-links a {
            color: #333;
            text-decoration: none;
            font-weight: 600;
            padding: 8px 10px;
        }
        .navbar .nav-links a:hover,
        .navbar .nav-links a:focus {
            color: #ff7043;
        }
        .dropdown-menu {
            display: none;
            position: absolute;
            top: 100%;
            left: 0;
            min-width: 170px;
            background: #fff;
            border: 1px solid rgba(255,112,67,0.18);
            border-radius: 12px;
            box-shadow: 0 16px 30px rgba(0,0,0,0.12);
            padding: 12px 0;
            z-index: 1001;
        }
        .navbar .nav-links li:hover .dropdown-menu,
        .navbar .nav-links li:focus-within .dropdown-menu {
            display: block;
        }
        .dropdown-menu a {
            display: block;
            padding: 10px 18px;
            color: #333;
            text-decoration: none;
            white-space: nowrap;
        }
        .dropdown-menu a:hover {
            background: #fff2e8;
            color: #ff7043;
        }
        .juice-list {
            list-style: none;
            padding: 0;
            max-width: 600px;
            margin: 0 auto;
            display: grid;
            gap: 10px;
        }
        .juice-list li {
            background: rgba(255,255,255,0.92);
            border: 1px solid #ffe0b2;
            border-radius: 14px;
            padding: 16px 20px;
            font-size: 1.05rem;
            color: #5d4037;
            box-shadow: 0 6px 18px rgba(0,0,0,0.05);
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 20px;
        }
        .juice-label {
            font-weight: 700;
            color: #ff7043;
            flex: 0 0 auto;
        }
        .juice-value {
            flex: 1 1 auto;
            text-align: right;
            color: #5d4037;
        }
        .navbar .nav-links a {
            color: #333;
            text-decoration: none;
            font-weight: 600;
        }
        .navbar .nav-links a:hover {
            color: #ff7043;
        }
        .hero {
            background: linear-gradient(135deg, #ffca28, #ff7043);
            color: #fff;
            padding: 120px 20px 80px;
            text-align: center;
        }
        .hero h1 {
            margin: 0;
            font-size: 3rem;
        }
        .hero p {
            max-width: 700px;
            margin: 20px auto 0;
            font-size: 1.2rem;
            line-height: 1.6;
        }
        .btn {
            display: inline-block;
            margin-top: 30px;
            padding: 14px 28px;
            background: #fff;
            color: #ff7043;
            text-decoration: none;
            border-radius: 30px;
            font-weight: bold;
        }
        .section {
            padding: 60px 20px;
            max-width: 1100px;
            margin: 0 auto;
        }
        .section h2 {
            text-align: center;
            margin-bottom: 30px;
            font-size: 2.2rem;
        }
        .cards {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
            gap: 20px;
        }
        .card {
            background: #fff;
            border-radius: 20px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.08);
            overflow: hidden;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            padding: 24px;
        }
        .card h3 {
            margin-top: 0;
            color: #ff7043;
        }
        .card p {
            line-height: 1.6;
        }
        .footer {
            text-align: center;
            padding: 30px 20px;
            background: #fff2e8;
            color: #6d4c41;
        }
        .contact-list {
            list-style: none;
            padding: 0;
            margin: 0;
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 16px;
        }
        .contact-list li {
            background: #fff;
            padding: 18px;
            border-radius: 16px;
            box-shadow: 0 8px 20px rgba(0,0,0,0.06);
        }
    </style>
</head>
<body>
    <header class="navbar">
        <div class="brand">Udupi Juice Center</div>
        <nav>
            <ul class="nav-links">
                <li>
                
                    </div>
                </li>
                <li><a href="Contact.php">Contact</a></li>
            </ul>
        </nav>
    </header>

    <section class="hero">
        <h1>Udupi Juice Center</h1>
        <p>Freshly squeezed juices, health shots, and energizing smoothie bowls made with premium fruits and natural ingredients. Come taste a brighter, healthier day at Udupi Juice Center.</p>
        <a href="#types-of-juices" class="btn">See Juice Types</a>
    </section>

    <section class="section" id="types-of-juices">
        <h2>Types of Juices</h2>
        <ul class="juice-list">
            <?php if (!empty($juices)): ?>
                <?php foreach ($juices as $j): ?>
                    <li>
                        <span class="juice-label">Name of juice</span>
                        <span class="juice-value"><a href="JuiceDetail.php?id=<?php echo (int) $j['id']; ?>"><?php echo htmlspecialchars($j['name'], ENT_QUOTES); ?></a></span>
                    </li>
                <?php endforeach; ?>
            <?php else: ?>
                <li>No juices available</li>
            <?php endif; ?>
        </ul>
    </section>

    <section class="section" id="menu">
        <h2>Our Best Sellers</h2>
        <div class="cards"></div>
    </section>

    <section class="section">
        <h2>Why Choose Us?</h2>
        <div class="cards">
            <div class="card">
                <h3>Natural Ingredients</h3>
                <p>Only real fruits and vegetables with no artificial flavors, colors or preservatives.</p>
            </div>
            <div class="card">
                <h3>Made Fresh Daily</h3>
                <p>Every juice and smoothie is prepared to order so you enjoy the freshest taste possible.</p>
            </div>
            <div class="card">
                <h3>Healthy & Delicious</h3>
                <p>Balanced flavor profiles that deliver both nutrition and refreshment in every glass.</p>
            </div>
        </div>
    </section>

    <section class="section">
        <h2>Visit Us</h2>
        <ul class="contact-list">
            <li>
                <strong>Location</strong>
                <p>Main Street, Udupi Juice Center</p>
            </li>
            <li>
                <strong>Phone</strong>
                <p>+91 12345 67890</p>
            </li>
            <li>
                <strong>Opening Hours</strong>
                <p>Mon - Sun: 8:00 AM - 8:00 PM</p>
            </li>
        </ul>
    </section>

    <footer class="footer">
        <p>&copy; <?php echo date('Y'); ?> Udupi Juice Center. Fresh tastes, healthy choices.</p>
    </footer>
</body>
</html>
